function imodel = iphmmprofestimate(model,ma,interactions, varargin)
%   IPHMMPROFESTIMATE estimates interaction profile HMM parameters using sequence weighting and
%   pseudocounts.
%
%   IPHMMPROFESTIMATE(MODEL,MULTIPLE_ALIGNMENT) returns a structure with the fields containing the
%   updated estimated parameters of a interaction profile HMM. Symbol emission and state transition
%   probabilities are estimated using the real counts and weighted pseudocounts obtained with the
%   background probabilities. In a previous step the algorithm calculates sequence weights according
%   to Henikoff & Henikoff (1994). Default weight is A=20, the default background symbol emission
%   for match and insert states is taken from MODEL.NullEmission, and the default background
%   transition probabilities can be changed in the initial part of the code.
%
%   Model construction: Multiple aligned sequences should contain uppercase letters and dashes
%   corresponding to the model MATCH and DELETE states that agree with MODEL.ModelLength. If model
%   state annotation is missing but MULTIPLE_ALIGNMENT is space aligned, then a "maximum entropy"
%   criterion is used to select MODEL.ModelLength states.
%
%   Notes: Insert and Flank Insert transition probabilities are not estimated, but can be modified
%   afterwards using HMMPROFSTRUCT. IPHMMPROFESTIMATE does not estimate 'fragment' profile models.
%
%   IPHMMPROFESTIMATE(...,'A',value) sets the pseudocount weight A to value when estimating the
%   symbol emission probabilities. The default value is 20. Note: for pure frequentist estimation
%   use A = 0.
%
%   IPHMMPROFESTIMATE(...,'Ax',value) sets the pseudocount weight Ax to value when estimating the
%   transition probabilities. The default value is 20. Note: for pure frequentist estimation use Ax
%   = 0.
%
%   IPHMMPROFESTIMATE(...,'BE',value) sets the background symbol emission probabilities. The default
%   values are taken from MODEL.NullEmission.
%
%   IPHMMPROFESTIMATE(...,'BMx',value) sets the background transition probabilities from MATCH
%   states ([M->M M->I M->D]). The default values are [0.998 0.001 0.001]. M->E are not estimated by
%   HMMPROFESTIMATE.
%
%   IPHMMPROFESTIMATE(...,'BDx',value) sets the background transition probabilities from DELETE
%   states ([D->M D->D]). The default values are [0.5 0.5].
%
%   IPHMMPROFESTIMATE(...,'BIx',value) sets the background transition probabilities from INSERT
%   states ([I->M I->I]). The default values are [0.5 0.5].
%
%   IPHMMPROFESTIMATE(...,'BBx',value) sets the background transition probabilities from the BEGIN
%   state ([B->D1 B->M1]). The default values are [0.01 0.99]. B->M[2...end] are not estimated by
%   IPHMMPROFESTIMATE.
%
%   Example:
%
%       % Load an existing profile HMM: 
%       newmodel = pfamhmmread('AAA_5.HMM');
%       
%       % You need a multiple sequence alignment (msa) as described above and the corresponding
%       % interaction profile (ipa) as cell arrays of strings: 
%       imodel = iphmmprofestimate(newmodel, msa, ipa);
%
%   See also IPHMMDECODE, HMMPROFSTRUCT, SHOWHMMPROF, HMMPROFALIGN

%   References:
%   
%   Modelling interaction sites in protein domains with interaction profile hidden Markov models
%   Torben Friedrich; Birgit Pils; Thomas Dandekar; Jörg Schultz; Tobias Müller
%   Bioinformatics 2006; doi: 10.1093/bioinformatics/btl486
%   
%   R. Durbin, S. Eddy, A. Krogh, and G. Mitchison. Biological Sequence Analysis. Cambridge UP,
%   1998.
%   
%   2005 Torben Friedrich Mail: torben.friedrich@biozentrum.uni-wuerzburg.de



% defining some constants
parmNames = {'A', 'Ax', 'BE', 'BM0x', 'BM1x', 'BDx', 'BIx', 'BBx'};

% check varargin
if rem(nargin,2) == 0
    error('Bioinfo:IncorrectNumberOfArguments','Incorrect number of arguments to %s.',mfilename);
end
if nargin > 3 && ~ischar([varargin{1:2:end}])
    error('Bioinfo:IncorrectParameterNames','Parameter names must be strings in %s.',mfilename);
end

% Defalut pseudocont constants
A=20; % for symbol emission, can be 5xR or other!
Ax=5; % for state transition

% % Default background transtions
% load('/home/binf016/matlab/mfiles/profile_hmm/InteractionHMMs/bgX.mat', 'backgroundTrans', 'bgBegin');
% % sums to convert the transition counts from the whole dataset to
% % transition percentages of the transition categories
% m0x_div = backgroundTrans(1) + backgroundTrans(2) + backgroundTrans(14) + backgroundTrans(16);
% m1x_div = backgroundTrans(4) + backgroundTrans(3) + backgroundTrans(5) + backgroundTrans(12);
% dx_div    = backgroundTrans(15) + backgroundTrans(6) + backgroundTrans(7);
% ix_div    = backgroundTrans(13) + backgroundTrans(11) + backgroundTrans(10);

qabx    = [ .00001 .499995 .499995 ];                                                               % BDX BNX BIX
qaex    = [ .499995 .499995 .00001 ];                                                               % NEX IEX DEX
qadx    = [ .49999 .49999 .00001 .00001 ];                                                       % DNX DIX DDX DEX
qaix     = [ .499995 .499995 .00001 0 ];                                                            % iNX iIX iiX iEX
qaixbl  = [ .5 .5 0 0 ];                                                                                         % transition to Insert in last profile site not allowed
qam0x = [ .499985 .499985 .00001 .00001 .00001 ];                                           % NNX NIX NDX NiX NEX
qam0xbl = [ .49999 .49999 .00001 0 .00001 ];                                                 % transition to Insert in last profile site not allowed
qam1x = [ .499985 .499985 .00001 .00001 .00001 ];                                       % IIX INX IDX IiX IEX
qam1xbl = [ .49999 .49999 .00001 0 .00001 ];                                                 % transition to Insert in last profile site not allowed


% Validate HMM model:
try
    model = checkhmmprof(model);
catch
    rethrow(lasterror);
end

% Validate multiple alignment:
if isstruct(ma)
    ma = fieldfromstruct(ma,'Sequence');
    if isempty(ma) || (iscell(ma)&&all(cellfun('isempty',ma)))
        error('Bioinfo:SequenceNotFoundInStructure',...
            'Sequence data was not found in the input structure.');
    end
end

% Validate interaction data:
if ~isstruct(interactions) & ~iscell(interactions)
    error('Bioinfo: IncorrectInputType', 'interactions has to be of class structure or cell.');
elseif isstruct(interactions)
    try
        interact_data = [ {interactions(:).interactions}' ];
    catch
        error('Bioinfo: IncorrectInputType', 'the following error occured while trying to read interaction data: %s', lasterr);
    end
elseif iscell(interactions)
    interact_data = interactions;
end

profLength = model.ModelLength;
isamino = strcmpi(model.Alphabet,'AA');
alphaLength = 4 + (isamino * 16);
extalphaLength = 4 + (isamino * 16 + 3);                                                     % possibility of having symbol X(23) in query sequence(and B and Z)
qa = [ model.NullEmission ];                                                                 % default background symbol probability

%%%%%%%% Optional Arguments %%%%%%%%%%%%%%%%%%%%%

if nargin > 3
    for j=1:2:nargin-3
        pname = varargin{j};
        pval = varargin{j+1};
        k = find(strcmp(lower(pname), lower(parmNames)));
        if numel(k) ~= 1
            k = strmatch(lower(pname), lower(parmNames));
        end
        if isempty(k)
            error('Bioinfo:UnknownParameterName',...
                'Unknown parameter name: %s.',pname);
        elseif length(k)>1
            error('Bioinfo:AmbiguousParameterName',...
                'Ambiguous parameter name: %s.',pname);
        else
            switch(k)
                case 1 % 'A' Pseudocount for Emission Probs.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=1 || pval<0 || pval>1e9
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    A = pval;
                case 2 % 'Ax' Pseudocount for Tx Prob.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=1 || pval<0 || pval>1e9
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    Ax = pval;
                case 3 % 'BE' Background Symbol Emission
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=alphaLength || any(pval<0)
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    qa = pval(:)'./sum(pval);
                case 4 % 'BM0x' Background Match Tx Prob.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=3 || any(pval<0)
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    qam0x = [pval(:)' 0]./sum(pval);
                case 5 % 'BM1x' Background Match Tx Prob.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=3 || any(pval<0)
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    qam1x = [pval(:)' 0]./sum(pval);
                case 6 % 'BDx' Background Delete Tx Prob.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=2 || any(pval<0)
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    qadx = pval(:)'./sum(pval);
                case 7 % 'BIx' Background Insert Tx Prob.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=2 || any(pval<0)
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    qaix = pval(:)'./sum(pval);
                case 8 % 'BBx' Background Begin Tx Prob.
                    if ~isnumeric(pval) || ~isreal(pval) || numel(pval)~=2 || any(pval<0)
                        error('Bioinfo:IncorrectParameterValue',...
                            'Incorrect value for parameter %s.',pname)
                    end
                    qabx = pval(:)'./sum(pval);
            end
        end
    end
end


% check validity of the multiple alignment

% input sequences must be a vertical concatenation of strings or string
% cells
if iscell(ma)
    ma = char(ma{:});
elseif isstruct(ma)
    name = fieldnames(ma);
    ma = char([[ {ma(:).name(1)}' ];])
end
if ~ischar(ma)
    error('Bioinfo:IncorrectInputType','Sequences must be string cells or an array of chars')
end

% Do the multiple aligned sequence have annotated states ?
% Same number of Caps and dashes in all sequences
if all(sum((ma >= 'A' & ma <= 'Z') | ma == '-', 2) == profLength) % if uppercase letters and dashes are present in a number corresponding to profLength in all seqs
    [ma,ptr] = hmmprofmerge2(ma, 'Interactions', interact_data); % a prealigned set of Sequences is aligned according to HMM-states, outputs are an hmm-alignment and a vector with indices of profile sites
else
    %assign model states to maximum entropy columns
    if isamino
        symCount=histc(aa2int(ma),1:alphaLength); % counts the number of aas seperately for every alignment coloumn, output is matrix aas by alignment coloumns with counts
    else
        symCount=histc(nt2int(ma),1:alphaLength);
    end
    %check for empty columns
    h = find(~sum(symCount));
    if h
        ma(:,h)=[];symCount(:,h)=[];
    end
    symProb=symCount./repmat(sum(symCount),alphaLength,1); % every count is divided by the full count of the coloumn
    entropy=(sum(symProb.*log2(symProb+(~symProb))));          % coloumn neg. entropies were calculated
    [dump,h]=sortrows([-sum(symCount);-entropy]');                  % sort neg. counts by ascending order and associate them with their entropy values(dump), other output "h" is a vector of indices ordered by counts and entropies
    ptr=sort(h(1:profLength));                                                    % profile positions are the positions with the highest aa-counts and lowest entropy, respectively; output ptr is vector with indices of profile sites
end
numSeq = size(ma,1);

%uniformazing spaces before converting to ints
ma(:) = regexprep(ma(:)','[~\.]','-');

if (isamino && ~isaa(ma(:, ptr))) || (~isamino && ~isnt(ma(:, ptr)))
    error('Bioinfo:IncorrectAlpha','Inconsistent alphabet in multiple alignment')
end

% Converting to int sequences; aminoacids are coded with numbers from 1 to
% 25 including iupac symbols as described in the function aa2int.
% Interaction encoding is done taking "27" as non-interacting, "28" as
% interacting and "26" for a by default non-interacting alignment position
% like a deletion or an insertion
ima = zeros(size(ma));
ima(ma == '0') = 27;
ima(ma == '1') = 28;
ima(ma == ' ') = 26;
niptr  = [];
iptr = [];
for si=1:numSeq
    if isamino
        ima(si, 1 : 2 : end)=aa2int(ma(si, 1 : 2 : end));
        dashint=aa2int('-');
        niptr = [ niptr; {ptr(ima(si,ptr+1) == 27)'} ];
        iptr = [ iptr; {ptr(ima(si,ptr+1) == 28)'} ];
    else
        ima(si, 1 : 2 : end)=nt2int(ma(si, 1 : 2 : end));
        dashint=nt2int('-');
    end
end

% weighting sequences according to Henikoffs position based weighting method
wgts = HenikoffWeights(ima, ptr);

count = histc(ima(:,ptr),1:extalphaLength);
nonintCount = zeros(alphaLength, length(ptr));
intCount = zeros(alphaLength, length(ptr));

for seqind = 1 : numSeq
    for profcount = 1 : length(ptr)
        if ptr(profcount) <= max(niptr{seqind}) & ~isempty(find(ptr(profcount) == niptr{seqind}))
            niprofcount = find(ptr(profcount) == niptr{seqind});
            intaa = ima(seqind, niptr{seqind}(niprofcount));
            switch intaa
                case 21
                    % 21 refers to symbol B for aspartic amino acids N(3, asparagine) and D(4, aspartic acid)
                    nonintCount(3:4, profcount) = nonintCount(3:4, profcount) + (0.5 * wgts(seqind));
                case 22
                    % 22 refers to symbol Z for glutamic amino acids Q(6, glutamine) and E(7, glutamic acid)
                    nonintCount(6:7, profcount) = nonintCount(6:7, profcount) + (0.5 * wgts(seqind));
                case 23
                    % 23 refers to any symbol
                    nonintCount(:, profcount) = nonintCount(:, profcount) + (0.05 * wgts(seqind));
                otherwise
                    nonintCount(ima(seqind, niptr{seqind}(niprofcount)), profcount) =...
                        nonintCount(ima(seqind, niptr{seqind}(niprofcount)), profcount) + (1 * wgts(seqind));
            end

        elseif ptr(profcount) <= max(iptr{seqind}) & ~isempty(find(ptr(profcount) == iptr{seqind}))
            iprofcount = find(ptr(profcount) == iptr{seqind});
            intaa = ima(seqind, iptr{seqind}(iprofcount));
            switch intaa
                case 21
                    % 21 refers to symbol B for aspartic amino acids N(3, asparagine) and D(4, aspartic acid)
                    intCount(3:4, profcount) = intCount(3:4, profcount) + (0.5 * wgts(seqind));
                case 22
                    % 22 refers to symbol Z for glutamic amino acids Q(6, glutamine) and E(7, glutamic acid)
                    intCount(6:7, profcount) = intCount(6:7, profcount) + (0.5 * wgts(seqind));
                case 23
                    % 23 refers to any symbol
                    intCount(:, profcount) = intCount(:, profcount) + (0.05 * wgts(seqind));
                otherwise
                    intCount(ima(seqind, iptr{seqind}(iprofcount)), profcount) =...
                        intCount(ima(seqind, iptr{seqind}(iprofcount)), profcount) + (1 * wgts(seqind));
            end

        end

    end
end
nonintCount = nonintCount .* numSeq;
intCount       = intCount .* numSeq;

% counts times it passed through the match state
inMatch             = ima(:, ptr) ~= dashint; % sequence sites belonging to the profile where there is no dash


% counts times it passed through an interacting match state
intMatch            = ima(:, ptr) ~= dashint & ima(:,ptr+1) == 28;

% counts times it passed through a non-interacting match state
nonintMatch       = ima(:, ptr) ~= dashint & ima(:,ptr+1) == 27;


% count symbols in the insert states
% and
% counts times it passed through the insert state
IUPACicount = zeros(extalphaLength, profLength);
icount          = zeros(alphaLength, profLength);
inInsert = zeros(numSeq, profLength);

for pi=1 : profLength - 1
    insertptr=ptr(pi) + 2 : 2 : ptr(pi+1)-1;                          % extract alignment sites between profile sites, problem: insert sites before first and after last profile site are not considered
    imat=ima(:, insertptr);                                          % matrix containing integers of insert symbols
    if ~isempty(insertptr)                                           % in case of insert states
        IUPACicount(:, pi)=histc(imat(:),1 : extalphaLength);           % counts symbols in insert matrix
        % see above IUPAC conversions
        icount(3:4, pi) = icount(3:4, pi) + 0.5 * IUPACicount(21, pi);
        icount(6:7, pi) = icount(6:7, pi) + 0.5 * IUPACicount(22, pi);
        icount(:, pi)     = icount(:, pi) + 0.05 * IUPACicount(23, pi);
        inInsert(:, pi)=sum(imat~=dashint, 2);                % sequence sites in non-profile sites where there is no dash
    end
end

ixCount = zeros(4, profLength-1);
m0xCount = zeros(5, profLength-1);
m1xCount = zeros(5, profLength-1);
dxCount = zeros(4, profLength-1);
bxCount = zeros(1, 3);
exCount = zeros(1, 3);


ixCount = [ sum((inInsert(:,1:end-1) & nonintMatch(:,2:end)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...      % i->m0; count times of insertions
    sum((inInsert(:,1:end-1) & intMatch(:,2:end)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...      % i->m1; count times of insertions
    sum((max(0,inInsert(:,1:profLength-1)-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...  % i->i; builds the sum of largest numbers of insertions for all profile sites
    zeros(1, profLength-1) ]';

% count transitions from non-interacting match state, last state always to "end" and
% no possibility of fragment alignment
m0xCount = [...
    sum((nonintMatch(:,1:end-1) & nonintMatch(:,2:end) & ~inInsert(:,1:end-1) & ~intMatch(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...  % m0->m0; at all sites where we can find a match in the actual and following position and where no insert state is entered
    sum((nonintMatch(:,1:end-1) & intMatch(:,2:end)      & ~inInsert(:,1:end-1) & ~intMatch(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...  % m0->m1; at all sites where we can find a match in the actual and following position and where no insert state is entered
    sum((nonintMatch(:,1:end-1) & inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...                             % m0->i; at all sites where the actual state is a match state and then an insert state is entered
    sum((nonintMatch(:,1:end-1) & ~inMatch(:,2:end)     & ~inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...% m0->d; conditions: beeing in a match state and following state is neither an insert nor a match
    zeros(1,profLength-1) ]';                                                               % m0->end; zero for all profiel sites except the last

% count transitions from interacting match state, last state always to "end" and
% no possibility of fragment alignment
m1xCount = [...
    sum((intMatch(:,1:end-1) & nonintMatch(:,2:end)      & ~inInsert(:,1:end-1) & ~nonintMatch(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...  % m1->m0; at all sites where we can find a match in the actual and following position and where no insert state is entered
    sum((intMatch(:,1:end-1) & intMatch(:,2:end) & ~inInsert(:,1:end-1) & ~nonintMatch(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...  % m1->m1; at all sites where we can find a match in the actual and following position and where no insert state is entered
    sum((intMatch(:,1:end-1) & inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...                             % m1->i; at all sites where the actual state is a match state and then an insert state is entered
    sum((intMatch(:,1:end-1) & ~inMatch(:,2:end)&~inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);...% m1->d; conditions: beeing in a match state and following state is neither an insert nor a match
    zeros(1,profLength-1) ]';                                                               % m1->end; zero for all profiel sites except the last

% count transitions from delete state, last state is uninformative
dxCount = [...
    sum((~inMatch(:,1:end-1) & nonintMatch(:,2:end) & ~inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);... % d->m0; not in match or insert now but in match in following state
    sum((~inMatch(:,1:end-1) & intMatch(:,2:end)       & ~inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);... % d->m1; not in match or insert now but in match in following state
    sum((~inMatch(:,1:end-1) & ~inMatch(:,2:end)     & ~inInsert(:,1:end-1)) .* repmat(wgts, 1, profLength-1) * numSeq, 1);... % d->d; not in match or insert now and also not in match in following state
    zeros(1, profLength-1) ]';

% count transitions from Begin state
bxCount = [ sum(~inMatch(:,1) .* wgts * numSeq) sum(nonintMatch(:,1) .* wgts * numSeq) sum(intMatch(:,1) .* wgts * numSeq, 1) ]; % insert transitions are covered by flankingInsertX; here only b-d, b-m0, b-m1

% count transition probabilities to End state
exCount = [ sum(nonintMatch(:, end) .* wgts * numSeq) sum(intMatch(:, end) .* wgts * numSeq) sum(~inMatch(:, end) .* wgts * numSeq) ];


% some counts may be zero, it is common to find "Divide by Zero" warnings
woff = warning('off');
% Estimate non-interacting match emission probabilities (pseudocount)
m0ep = ((nonintCount+A*repmat(qa',1,profLength))./repmat(sum(nonintCount)+A,alphaLength,1))'; % qa...default background emission, A...pseudocount
m0ep(isnan(m0ep)) = 1/alphaLength;                                                                          % mep entries with the value "NaN" were set to 1/alphaLength
% Estimate interacting match emission probabilities (pseudocount)
m1ep = ((intCount+A*repmat(qa',1,profLength))./repmat(sum(intCount)+A,alphaLength,1))'; % qa...default background emission, A...pseudocount
m1ep(isnan(m1ep)) = 1/alphaLength;                                                                          % mep entries with the value "NaN" were set to 1/alphaLength
% Estimate insert emission probabilities (pseudocount)
iep = ((icount+A*repmat(qa',1,profLength))./repmat(sum(icount)+A,alphaLength,1))';
iep(isnan(iep)) = 1/alphaLength;
% Estimate non-interacting match transition probabilities (pseudocount)
m0xp = ((m0xCount + Ax * [ repmat(qam0x,profLength-2,1); qam0xbl ]) ./ repmat(sum(m0xCount,2) + Ax, 1, 5)); % Ax...pseudocount
m0xp(isnan(m0xp)) = 0.25;
% Estimate interacting match transition probabilities (pseudocount)
m1xp = ((m1xCount + Ax * [ repmat(qam1x,profLength-2,1); qam1xbl ])./repmat(sum(m1xCount,2)+Ax,1,5)); % Ax...pseudocount
m1xp(isnan(m1xp)) = 0.25;
% Estimate delete transition probabilities (pseudocount)
dxp = ((dxCount + Ax * repmat(qadx,profLength-1,1)) ./ repmat(sum(dxCount,2) + Ax,1,4));
dxp(isnan(dxp)) = 0.33;
% Estimate insert transition probabilities (pseudocount)
ixp = ((ixCount + Ax * [ repmat(qaix,profLength-2,1); qaixbl ])./repmat(sum(ixCount,2)+Ax,1,4));
ixp(isnan(ixp)) = 0.33;
warning(woff);

% Estimate begin transition probabilities (pseudocount)
bxp = [ zeros(1,3); (bxCount+Ax*qabx)/(sum(bxCount)+Ax); zeros(profLength-1,3) ];       % horizontal vector; first three values are BDX, BM0X, BM1X; transitions from B to states of further sites is set to 0!

% Estimate end transition probabilities
endxp = [ zeros(profLength, 3); (exCount+Ax*qaex)/(sum(exCount)+Ax) ];        % matrix profile Length x possible transitions (M0Ex M1Ex DEx)


imodel.niMatchEmission = [ zeros(1, alphaLength); m0ep ];
imodel.iMatchEmission   = [ zeros(1, alphaLength); m1ep ];
imodel.InsertEmission    = [ zeros(1, alphaLength); iep ];
imodel.niMatchX           = [ 0 0 0 0 0; m0xp; 0 0 0 0 1 ];                            % add end state and 0 state transitions to the state transitions matices
imodel.iMatchX             = [ 0 0 0 0 0; m1xp; 0 0 0 0 1 ];
imodel.DeleteX             = [ 0 0 0 0; dxp; 0 0 0 1 ];
imodel.InsertX              = [ 0 0 0 0; ixp; 0 0 0 0 ];
imodel.BeginX               = bxp;
imodel.EndX                 = endxp;
imodel.Alphabet           = model.Alphabet;
imodel.NullX                = model.NullX;
imodel.NullEmission      = qa;
imodel.Name               = model.Name;
% imodel.ProfileMSA         = model.ProfileMSA;
imodel.ptr                    = ptr;
% imodel.Interactions        = model.SeqInteractionSites;
imodel.LoopX                 = model.LoopX;
imodel.FlankingInsertX   = model.FlankingInsertX;
imodel.ModelLength      = model.ModelLength;