This package includes matlab scripts to work with a new kind of hidden Markov models, the interaction profile HMMs. Detailed instructions how to use the different Matlab functions can be display with Matlab using the command HELP <FUNCTION>.

Requirements:

1. You will have to install Matlab (the scripts are tested under versions 6 & 7) and the bioinformatics toolbox

2. It is recommended that you import profileHMMs with pfamhmmread from the bioinformatics toolbox for estimating ipHMMs. These pHMMs can be reestimated 	to ipHMMs with the function IPHMMPROFESTIMATE.


For further questions and suggestions contact:

torben.friedrich@biozentrum.uni-wuerzburg.de

Reference:

Modelling interaction sites in protein domains with interaction profile hidden
Markov models Torben Friedrich; Birgit Pils; Thomas Dandekar; Jörg Schultz; Tobias Müller
Bioinformatics 2006; doi: 10.1093/bioinformatics/btl486