function wgts = HenikoffWeights(dgtAli, pointer);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% HenikoffWeights weights sequences of a multiple sequence alignment according to Vingron and
% Sibbald(1993) as well as Henikoff and Henikoff(1994) in a position based way. 
% In an alignment of k sequences and i sites the column weight of sequence k is 
% `w(ki)=1/n(ai)*m(i) with n(ai)..amount of aminoacid a of the sequence k over the whole column i
% and m(i)..number of different aminoacids in column i.
% The normalized weight of sequence k w(k) = sum(i)[`w(ki)]/sum(k)[`w(k)]
% This function works with an extended alphabet with 2*20 aas for non-interacting and interacting
% symbols.
% input: dgtAli...the digitized Alignment(see aa2int) and the numbers 26 for ' ', 27 for '0' and 28
%           for '1'
%          pointer...pointer to matching MSA-sites 
% output: wgts...a vector of sequence weights
%
% The weighting only concerns alignment matching sites
% 
% Author: Torben Friedrich, 2005
% 
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

colWeights = [];

[ row column ] = size(dgtAli);
wAli = zeros(row, length(pointer));

for i = 1 : 2 : pointer(end)
    if ~isempty(find(pointer(:) == i))
        zeroWeight = [];
        for k = 1 : row
            if dgtAli(k, i+1) == 27
                wAli(k, i) = dgtAli(k, i);
            elseif dgtAli(k, i+1) == 26
                wAli(k, i) = 41;                                                                   % deletions indicated by 41
            elseif dgtAli(k, i) < 21
                wAli(k, i) = dgtAli(k, i) + 20;
            elseif dgtAli(k, i) > 20 && dgtAli(k, i) < 25
                wAli(k, i) = 0;
                zeroWeight = [ zeroWeight k ];
            end
        end
        colVec = wAli(:, i);
        colDist = histc(colVec(colVec~=0), [ 1 : 41 ]);
        m = sum(colDist ~= 0);
        if isempty(zeroWeight)
            colWeights = [ colWeights 1./(colDist(colVec).*m) ];
        elseif length(zeroWeight) == 1
            tempWeights = [ 1./(colDist(colVec(1 : zeroWeight-1)).*m); 0; 1./(colDist(colVec(zeroWeight+1 : end)).*m) ];
            colWeights = [ colWeights tempWeights ];
        else
            tempWeights = [];
            for noweight = 1 : length(zeroWeight)
                if noweight == 1
                    tempWeights = [ tempWeights; 1./(colDist(colVec(1 : zeroWeight(noweight)-1)).*m); 0 ];
                elseif noweight == length(zeroWeight)
                    tempWeights = [ tempWeights; 1./(colDist(colVec(zeroWeight(noweight-1)+1 : zeroWeight(noweight)-1)).*m); 0;...
                        1./(colDist(colVec(zeroWeight(noweight)+1 : end)).*m) ];
                else
                    tempWeights = [ tempWeights; 1./(colDist(colVec(zeroWeight(noweight-1)+1 : zeroWeight(noweight)-1)).*m); 0 ];
                end
            end
        end
%         disp(i)
    end
end

seqWeights = sum(colWeights, 2);
wgts = seqWeights./sum(seqWeights);
