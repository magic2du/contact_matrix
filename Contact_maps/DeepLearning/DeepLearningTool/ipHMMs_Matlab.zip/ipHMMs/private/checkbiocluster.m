function checkbiocluster(jm,waitInQueue)
% CHECKBIOCLUSTER check the existence and availability of a cluster.

%   Copyright 2003-2005 The MathWorks, Inc.
%   $Revision: 1.1.8.1 $  $Date: 2005/06/09 21:57:18 $

if ~isa(jm,'distcomp.jobmanager')
    if isempty(ver('distcomp'))
        error('Bioinfo:checkbiocluster:NoDCT',...
              'The Distributed Computing Toolbox is required to distribute the algorithm into a cluster of computers.')
    else
        error('Bioinfo:checkbiocluster:InvalidJobManager',...
            'Invalid job manager. Use findResource from the Distributed Computing Toolbox to find a valid job manager.')
    end
end
state = jm.State;
if strcmp(state,'unavailable')
    error('Bioinfo:checkbiocluster:JobManagerUnavailable',...
        'Job manager is unavailable.')
end
if ~strcmp(state,'running')
    error('Bioinfo:checkbiocluster:JobManagerNotRunning',...
        'Job manager ''%s'' state is not ''running''.',jm.Name)
end

u = get(jm.Jobs,'State');

if ~waitInQueue && (any(strcmp(u,'queued')) || any(strcmp(u,'running')))
    error('Bioinfo:checkbiocluster:NoIddleWorkers',...
          'Job manager ''%s'' does not have available resources. To wait in the queue set the option WAITINQUEUE to true.',jm.Name)
end


