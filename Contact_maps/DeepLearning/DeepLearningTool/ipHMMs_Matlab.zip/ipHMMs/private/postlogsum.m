function lgsum = postlogsum( sc1, sc2, logtable);

% A function to calculate the a sum of probabilities in log-space
% Inputs: sc1, sc2 are two logarithmic bit scores to sum up
% Output: the result of the operation sc1 + log(1 + exp(sc1-sc2)) for sc1 > sc2 or
% sc2 + log(1 - exp(sc1-sc2)) for sc2 > sc1
%     
% Author: Torben Friedrich, 2004


diff = round(sc1 - sc2) ;
if sc1 == -inf & sc2 == -inf
    lgsum = sc1;
elseif diff >= length(logtable)
    lgsum = sc1;
elseif diff <= -length(logtable)
    lgsum = sc2;
elseif diff > 0
    lgsum = sc1 + logtable(diff+1);        % +1 because 0 as index isn't allowed in matlab 
elseif diff <= 0
    lgsum = sc2 + logtable((-diff)+1);
end